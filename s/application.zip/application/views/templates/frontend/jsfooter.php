<script src="<?php echo base_url('assets/frontend/js/jquery.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/js/materialize.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/lib/owlcarousel/owl.carousel.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/lib/Magnific-Popup-master/dist/jquery.magnific-popup.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/lib/slick/slick/slick.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/js/custom.js');?>"></script>
</body>

</html>