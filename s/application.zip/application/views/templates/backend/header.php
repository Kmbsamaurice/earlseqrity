<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Earl communications-Admin Dashboard</title>
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/backend/');?>images/favicon.png">
    <link href="<?php echo base_url('assets/backend/');?>font-awesome/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/backend/');?>datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/backend/');?>css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">