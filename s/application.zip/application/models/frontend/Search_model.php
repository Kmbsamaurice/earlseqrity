<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_model extends CI_Model {
    public function search($search_string){
        $search_string = '%' . $search_string . '%';
        $sql = "SELECT * 
                FROM products p
                JOIN categories c 
                ON p.catid = c.catid
                JOIN brands b 
                ON p.brandid = b.brandid
                WHERE p.product like ? OR p.description like ? 
                ORDER BY p.id DESC";
        $query = $this->db->query($sql,array($search_string,$search_string));
        return $query->result_array();
    }
    public function search_total($search_string){
        $search_string = '%' . $search_string . '%';
        $sql = "SELECT * 
                FROM products p
                JOIN categories c 
                ON p.catid = c.catid
                JOIN brands b 
                ON p.brandid = b.brandid
                WHERE p.product like ? OR p.description like ?
                ORDER BY p.id DESC";
        $query = $this->db->query($sql,array($search_string,$search_string));
        return $query->num_rows();
    }
}