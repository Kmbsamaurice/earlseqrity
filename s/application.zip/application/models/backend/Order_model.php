<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

    class Order_model extends CI_Model{
        public function orders(){
            return $this->db->select('*')
                    ->from('orders')
                    ->order_by('order_id', 'DESC')
                    ->join('customers','customers.id = orders.customer_id')
                    ->join('shipping','shipping.shipping_id = orders.shipping_id')
                    ->join('payment','payment.payment_id = orders.payment_id')
                    ->get()
                    ->result();
        }
    
        //count the number of orders in the table orders
        public function countorders(){
            $this->db->from('orders');
            return $count = $this->db->count_all_results();
        }
        public function orderdetails_id($order_id){
            return $this->db->select('*')
                   ->from('orders')
                   ->where('order_id',$order_id)
                   ->get()
                   ->row();
       }
       public function customerdetails_id($customer_id){
        return $this->db->select('*')
                ->from('customers')
                ->where('id',$customer_id)
                ->get()
                ->row();
    }
    public function shippingdetails_id($shipping_id){
        return $this->db->select('*')
                ->from('shipping')
                ->where('shipping_id',$shipping_id)
                ->get()
                ->row();
    }
    public function orderdetailsby_id($order_id){
        return $this->db->select('*')
                ->from('order_details')
                ->where('order_id',$order_id)
                ->get()
                ->result();
    }
    }
