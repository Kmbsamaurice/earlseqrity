<?php

		define('GUSER', 'sales@earlcommunications.com'); // email address
        define('GPWD', 'E4RL@Connect'); // email password
        define('HOST', 'mail.earlcommunications.com'); // email server host
        define('PORT',465); // email server port

        /**
         * Gmail host smtp.gmail.com
         * Gmail port 465
         */

?>